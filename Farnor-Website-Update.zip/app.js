const services=[
{title:'ایمپلنت دندان',description:'بررسی روش‌های جایگزینی دندان از دست‌رفته با توجه به شرایط استخوان و لثه.',id:'implant'},
{title:'بازسازی کامل فک و دهان',description:'برنامه‌ریزی درمان‌های چندمرحله‌ای برای بازگرداندن عملکرد و زیبایی دهان.',id:'full-mouth'},
{title:'لمینت سرامیکی',description:'اصلاح ظاهر دندان‌ها پس از ارزیابی سلامت و ساختار دندان.',id:'laminate'},
{title:'کامپوزیت ونیر',description:'اصلاح فرم و رنگ دندان‌ها با مواد ترمیمی در موارد مناسب.',id:'composite'},
{title:'ارتودنسی',description:'ارزیابی و اصلاح نامرتبی دندان‌ها و روابط فکی.',id:'orthodontics'},
{title:'پروتز و دندان مصنوعی',description:'راهکارهای ثابت و متحرک برای جایگزینی دندان‌های ازدست‌رفته.',id:'prosthetics'},
{title:'عصب‌کشی و ترمیم',description:'درمان مشکلات پالپ و ترمیم دندان‌های آسیب‌دیده.',id:'root-canal'},
{title:'جراحی دندان و لثه',description:'ارزیابی نیاز به درمان‌های جراحی دهان و لثه.',id:'surgery'},
{title:'جرم‌گیری و بلیچینگ',description:'مراقبت از بهداشت دهان و بررسی روش‌های روشن‌سازی دندان.',id:'whitening'},
{title:'دندانپزشکی کودکان',description:'معاینه و مراقبت‌های پیشگیرانه و درمانی متناسب با سن کودک.',id:'pediatric'}
];
const grid=document.getElementById('serviceGrid');if(grid){grid.innerHTML=services.map((s,i)=>`<a class="service-card" href="services.html#${s.id}"><span class="service-icon">${String(i+1).padStart(2,'0')}</span><h3>${s.title}</h3><p>${s.description}</p><span class="more">آشنایی با خدمت ←</span></a>`).join('')}
const details=document.getElementById('serviceDetails');if(details){details.innerHTML=services.map((s,i)=>`<article class="detail-card" id="${s.id}"><span class="eyebrow">SERVICE ${String(i+1).padStart(2,'0')}</span><h2>${s.title}</h2><p>${s.description}</p><p>انتخاب روش درمان، مراحل و هزینه احتمالی پس از معاینه و بررسی وضعیت دهان و دندان مشخص می‌شود.</p><a class="btn" href="consultation.html">درخواست مشاوره</a></article>`).join('')}
const menu=document.getElementById('menu'),nav=document.getElementById('nav');if(menu&&nav){menu.addEventListener('click',()=>{const opened=nav.classList.toggle('open');menu.setAttribute('aria-expanded',String(opened))})}
